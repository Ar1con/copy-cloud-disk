create definer = root@localhost trigger setChangetime
    before update
    on myfile
    for each row
BEGIN
		
		SET new.changetime = now();

END;

